﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using bank.service_bank;

namespace bank
{
    public partial class Form1 : Form
    {
        service_bank.bank_webserviceSoapClient cliente = new service_bank.bank_webserviceSoapClient();
        service_bank.Bank_Client cliente2 = new service_bank.Bank_Client();
       
        public bank_webserviceSoapClient Cliente { get => cliente; set => cliente = value; }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label3.Visible = false;
            
            textBox2.Visible = false;
            
            
        }

        private void consultar_Click(object sender, EventArgs e)
        {
            int account;
            textBox3.Text = "";

            textBox3.Text = "";
            account = Convert.ToInt32(textBox1.Text);
            if (comboBox1.SelectedItem == "Balance")
            {
                cliente2 =Cliente.Balance_Account(Convert.ToInt32(textBox1.Text));
                textBox3.Text += "Account Number: "+ Convert.ToString(cliente2.Account_Number) +"\r\n";
                textBox3.Text += "Balance: " + Convert.ToString(cliente2.Balance) + "\r\n";
                textBox3.Text += "Message: " + Convert.ToString(cliente2.Message) + "\r\n";
                textBox3.Text += "Succesfull: " + Convert.ToString(cliente2.SuccesFull) + "\r\n";
                Console.WriteLine(cliente2.Balance);
            }
            if (comboBox1.SelectedItem == "Deposit")
            {
            
                cliente2 = Cliente.Deposit_Account(Convert.ToInt32(textBox1.Text), Convert.ToDecimal(textBox2.Text));
                cliente2 = Cliente.Balance_Account(Convert.ToInt32(textBox1.Text));
                textBox3.Text += "Account Number: " + Convert.ToString(cliente2.Account_Number) + "\r\n";
                textBox3.Text += "Balance: " + Convert.ToString(cliente2.Balance) + "\r\n";
                textBox3.Text += "Message: " + Convert.ToString(cliente2.Message) + "\r\n";
                textBox3.Text += "Succesfull: " + Convert.ToString(cliente2.SuccesFull) + "\r\n";
            }
            if(comboBox1.SelectedItem == "Withdraw")
            {
             
                cliente2 = Cliente.With_draw(Convert.ToInt32(textBox1.Text), Convert.ToDecimal(textBox2.Text));
                cliente2 = Cliente.Balance_Account(Convert.ToInt32(textBox1.Text));
                textBox3.Text += "Account Number: " + Convert.ToString(cliente2.Account_Number) + "\r\n";
                textBox3.Text += "Balance: " + Convert.ToString(cliente2.Balance) + "\r\n";
                textBox3.Text += "Message: " + Convert.ToString(cliente2.Message) + "\r\n";
                textBox3.Text += "Succesfull: " + Convert.ToString(cliente2.SuccesFull) + "\r\n";
                
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == "Deposit" || comboBox1.SelectedItem == "Withdraw" )
            {
                label2.Visible = true;
                label3.Visible = true;
                
                textBox2.Visible = true;
            }
            if(comboBox1.SelectedItem == "Balance")
            {
                label3.Visible = false;
                textBox2.Visible = false;
            }
            
            
        }
    }
}
