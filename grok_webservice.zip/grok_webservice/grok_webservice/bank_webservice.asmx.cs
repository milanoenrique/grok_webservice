﻿using grok_webservice.controllers;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Script.Services;
using System.Web.Services;

namespace grok_webservice
{
    /// <summary>
    /// Summary description for bank_webservice
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class bank_webservice : System.Web.Services.WebService
    {
       

        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public Bank_Client Balance_Account(int account)
        {

            Bank_Client balance_cliente = new Bank_Client();
            balance_cliente.Balance_account(account);

            
            return balance_cliente;



        }
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public Bank_Client Deposit_Account(int account, decimal amount)
        {

            Bank_Client balance_cliente = new Bank_Client();
            balance_cliente.Deposit_account(account, amount);


            return balance_cliente;



        }
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public Bank_Client With_draw(int account, decimal amount)
        {
            Bank_Client balance_cliente = new Bank_Client();
            balance_cliente.Witdraw_account(account, amount);
            return balance_cliente;
        }

        

    }
}
