﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace grok_webservice.controllers
{
    public class Bd
    {
        public static SqlConnection conectar = new SqlConnection();
        public static  string Abrir_conexion()
        {
            
            conectar.ConnectionString = "Data Source=9470M-ID;Initial Catalog=grok;Integrated Security=True";
            conectar.Close();
            try
            {
                conectar.Open();
                return "Conecto";
            }
            catch (Exception ex)
            {
                return "Error Conectando a la BD" + ex.Message;
            }
            

            
        }
        
    }
}