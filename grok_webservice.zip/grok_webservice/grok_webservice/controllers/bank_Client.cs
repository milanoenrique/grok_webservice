﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.ServiceModel;
using System.Windows.Forms;

namespace grok_webservice.controllers
{
    [ServiceContract]
   

    public class Bank_Client 
    {
        public  int Account_Number;
        public decimal Balance;
        public string Message;
        public bool SuccesFull;

        private string sql = "Data Source=9470M-ID;Initial Catalog=grok;Integrated Security=True";



       [OperationContract]
        public void Balance_account(int account)
        {
            SqlConnection conectar = new SqlConnection();
            conectar.ConnectionString = sql;

            SqlCommand cmd = new SqlCommand("sp_get_balance",conectar);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@account", SqlDbType.Int).Value = account;
            conectar.Open();
            SqlDataReader temp = cmd.ExecuteReader();

            while (temp.Read())
            {
                Balance = Convert.ToDecimal(temp[1]);
                Account_Number = Convert.ToInt32(temp[0]);
                SuccesFull = true;
                Message = "Operation complete!";
            }
        }
        [OperationContract]
        public void Deposit_account(int account, decimal amount)
        {
            Balance_account(account);
            SqlConnection conectar = new SqlConnection();
            conectar.ConnectionString = sql;

            SqlCommand cmd = new SqlCommand("sp_deposit_account", conectar);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@account", SqlDbType.Int).Value = account;
            cmd.Parameters.Add("@amount", SqlDbType.Decimal).Value = amount;
            conectar.Open();
            int num_row = cmd.ExecuteNonQuery();
            
            if (num_row > 0)
            {
                Balance_account(account);
                Message = "Operation complete!";
                SuccesFull = false;
            }
            else
            {
                Message = "Operation incomplete!";
                SuccesFull = true;
            }

        }

        [OperationContract]
        public void Witdraw_account(int account, decimal amount)
        {
            Balance_account(account);
            SqlConnection conectar = new SqlConnection();
            conectar.ConnectionString = sql;

            SqlCommand cmd = new SqlCommand("sp_withdraw", conectar);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@account", SqlDbType.Int).Value = account;
            cmd.Parameters.Add("@amount", SqlDbType.Decimal).Value = amount;
            conectar.Open();
            int num_row = cmd.ExecuteNonQuery();
            
            conectar.Close();
            if (num_row > 0)
            {
                Balance_account(account);
                Message = "Operation complete!";
                SuccesFull = false;
            }
            if(num_row<0)
            {
                Balance_account(account);
                
                Message = "Operation incomplete!";
                SuccesFull = false;
            }
           
            
        }

    }

   
}